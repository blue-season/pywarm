# 09-10-2019;

""" `warm.up` is an alias of
[`warm.engine.prepare_model_`](https://blue-season.github.io/pywarm/reference/warm/engine/#prepare_model_). """
from warm.engine import prepare_model_ as up
