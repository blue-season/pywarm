# 09-10-2019;
from warm.engine import prepare_model_ as up
""" `warm.up` is an alias of `warm.engine.prepare_model_`. """
