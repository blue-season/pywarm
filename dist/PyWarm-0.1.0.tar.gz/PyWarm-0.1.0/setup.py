# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['warm']

package_data = \
{'': ['*']}

install_requires = \
['toml>=0.9']

setup_kwargs = {
    'name': 'pywarm',
    'version': '0.1.0',
    'description': 'A cleaner way to build neural networks for PyTorch.',
    'long_description': '\n![PyWarm Logo](docs/pywarm-logo.png)\n\n# PyWarm\n\nA cleaner way to build neural networks for PyTorch.\n\n## Introduction\n\nPyWarm is a high-level neural network construction API for PyTorch.\nIt only aims to simplify the network definition, and does not cover\nmodel training, validation and data handling.\n\nWith PyWarm, you can put *all* network data flow logic in the `forward()` method of\nyour model, without the need to define children modules in the `__init__()` method.\nThis result in a much readable model definition in fewer lines of code.\n\n----\n\nFor example, a convnet for MNIST:\n(Click the tabs to switch between Warm and Torch versions)\n\n\n``` Python tab="Warm" linenums="1"\nimport torch.nn as nn\nimport torch.nn.functional as F\nimport warm\nimport warm.functional as W\n\n\nclass ConvNet(nn.Module):\n\n    def __init__(self):\n        super().__init__()\n        warm.engine.prepare_model_(self, [1, 1, 28, 28])\n\n    def forward(self, x):\n        x = W.conv(x, 20, 5, activation=\'relu\')\n        x = F.max_pool2d(x, 2)\n        x = W.conv(x, 50, 5, activation=\'relu\')\n        x = F.max_pool2d(x, 2)\n        x = x.view(-1, 800)\n        x = W.linear(x, 500, activation=\'relu\')\n        x = W.linear(x, 10)\n        return F.log_softmax(x, dim=1)\n```\n\n``` Python tab="Torch" linenums="1"\n# from pytorch tutorials/beginner_source/blitz/neural_networks_tutorial.py \nimport torch.nn as nn\nimport torch.nn.functional as F\n\n\nclass ConvNet(nn.Module):\n\n    def __init__(self):\n        super().__init__()\n        self.conv1 = nn.Conv2d(1, 20, 5, 1)\n        self.conv2 = nn.Conv2d(20, 50, 5, 1)\n        self.fc1 = nn.Linear(4*4*50, 500)\n        self.fc2 = nn.Linear(500, 10)\n\n    def forward(self, x):\n        x = F.relu(self.conv1(x))\n        x = F.max_pool2d(x, 2, 2)\n        x = F.relu(self.conv2(x))\n        x = F.max_pool2d(x, 2, 2)\n        x = x.view(-1, 4*4*50)\n        x = F.relu(self.fc1(x))\n        x = self.fc2(x)\n        return F.log_softmax(x, dim=1)\n```\n\n----\n\nA couple of things you may have noticed:\n\n-   First of all, in the PyWarm version, the entire network definition and\n    data flow logic resides in the `forward()` method. You don\'t have to look\n    up and down repeatedly to understand what `self.conv1`, `self.fc1` etc.\n    is doing.\n\n-   You do not need to track and specify `in_channels` (or `in_features`, etc.)\n    for network layers. PyWarm can infer the information for you. e.g.\n\n```Python\n# Warm\nx = W.conv(x, 20, 5, activation=\'relu\')\nx = W.conv(x, 50, 5, activation=\'relu\')\n\n\n# Troch\nself.conv1 = nn.Conv2d(1, 20, 5, 1)\nself.conv2 = nn.Conv2d(20, 50, 5, 1)\n```\n\n-   One unified `W.conv` for all 1D, 2D, and 3D cases.\n    Fewer things to keep track of!\n\n----\n## Quick start: 30 seconds to PyWarm\n\nIf you already have experinces with PyTorch, using PyWarm is very straightforward:\n\n-   First, import PyWarm in you model file:\n```Python\nimport warm\nimport warm.functional as W\n```\n\n-   Second, delete child module definitions in the model\'s `__init__()` method.\n    In stead, use `W.conv`, `W.linear` ... etc. in the model\'s `forward()` method,\n    just like how you would use `F.max_pool2d`, `F.relu` ... etc.\n\n    For example, instead of writing:\n\n```Python\n# Torch\nclass MyModule(nn.Module):\n    def __init__(self):\n        ...\n        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size)\n        ...\n    def forward(self, x):\n        x = self.conv1(x)\n```\n\n-   You can now write in the warm way:\n\n```Python\n# Warm\nclass MyWarmModule(nn.Module):\n    def __init__(self):\n        ...\n        warm.engine.prepare_model_(self, input_shape_or_data)\n    def forward(self, x):\n        x = W.conv(x, out_channels, kernel_size) # no in_channels needed\n```\n\n-   Finally, don\'t forget to warmify the model by adding\n    \n    `warm.engine.prepare_model_(self, input_shape_or_data)`\n\n    at the end of the model\'s `__init__()` method. You need to supply\n    `input_shape_or_data`, which is either a tensor of input data, \n    or just its shape, e.g. `[1, 1, 28, 28]` for MNIST inputs.\n    \n    The model is now ready to use, just like any other PyTorch models.\n\n\n----\n## Installation\n\n    pip3 install pywarm\n\n',
    'author': 'blue-season',
    'author_email': 'very.blue.season@gmail.com',
    'url': 'https://github.com/blue-season/pywarm',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6',
}


setup(**setup_kwargs)
